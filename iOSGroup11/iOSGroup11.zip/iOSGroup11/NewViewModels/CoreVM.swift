//
//  CoreVM.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-13.
//

import Foundation
import SwiftData
import SwiftUI
import UIKit

extension StartPageView{
    @Observable
    final class ViewModel{
        private let modelContext: ModelContext
        var categories = [Category2]()
        var todos = [TodoTask]()
        var imageModel = ImageModel()
        var images: [ImageData.ApiImage] = []
        
        var errorMessage: String?
        
        var fillLevel = 0
        let totalHeights = 14
      
   
        

        var imageHandler: ImageHandling
            
        init(modelContext: ModelContext, imageHandler: ImageHandling) {
           // modelContext.insert(Category2.defaultCategory)
            self.modelContext = modelContext
            self.imageHandler = imageHandler
            fetchData()
        }
/*
        init(modelContext: ModelContext) {
            self.modelContext = modelContext
            
            modelContext.insert(Category2.defaultCategory)
            fetchData()
        }*/
      
        /*
        init(modelContext: ModelContext) {
            self.modelContext = modelContext
            modelContext.insert(Category2.defaultCategory)
            fetchData()
        }
        */
        func fetchData() {
            do {
                let descriptor = FetchDescriptor<TodoTask>(sortBy: [SortDescriptor(\.title)])
                todos = try modelContext.fetch(descriptor)
            } catch {
                print("Fetch failed")
            }
            do {
                let descriptor2 = FetchDescriptor<Category2>(sortBy: [SortDescriptor(\.title)])
                categories = try modelContext.fetch(descriptor2)
            }catch{
                print("Fetch for categories fail")
            }
            
            
        }
        
        /*************
         * CATEGORIES
         *******************/
        func saveCategory(title: String, imageURL: String?) async {
            do{
                try validateCategory(title: title)
                guard let imageURL = imageURL, !imageURL.isEmpty else {
                    return
                }
                let newCategory = Category2(title: title, imageId: nil)
                
                try await updateCategoryImage(category: newCategory, newImageURL: imageURL)
                
                let backgroundImage = try await downloadImageGetFilepath(imageURL: imageURL)
                
                modelContext.insert(newCategory)
                fetchData()
            }catch{
                
            }
        }
        func updateCategoryImage2(category: Category2, newImageURL: String) async throws {
     
            let newImageFileName = URL(string: newImageURL)?.lastPathComponent ?? "default.jpg"
            let newImageFilePath = try await imageHandler.downloadImage(imageURL: newImageURL)

            if let currentImageId = category.imageId, !currentImageId.isEmpty {
       
            }
   
            category.imageId = newImageFilePath
            
           
        }
 
        
        func updateCategory(category: Category2, newImageURL: String, currentImageURL: String?) async throws {
            try await updateCategoryImage(category: category, newImageURL: newImageURL)
               fetchData()
        }
        //https://www.mozzlog.com/blog/how-to-delete-file-swift-using-foundation
        func updateCategoryImage(category: Category2, newImageURL: String) async throws{
                if let currentImageURL = category.imageId, !currentImageURL.isEmpty {
                    let currentImagePath = getDocumentsDirectory().appendingPathComponent(currentImageURL).path
                    try? FileManager.default.removeItem(atPath: currentImagePath)
                }
                let newImageFilePath = try await downloadImageGetFilepath(imageURL: newImageURL)
                category.imageId = newImageFilePath
                
            fetchData()
        }
        

        func validateCategory(title: String) throws {
            guard !title.isEmpty else {
                throw CategoryError.missingTitle
            }
            guard title.count <= 35 else {
                throw CategoryError.titleTooLong
            }
        }
     
        func deleteCategory(at offsets: IndexSet) {
            offsets.forEach { index in
                let categoryToDelete = categories[index]
                modelContext.delete(categoryToDelete)
            }
            fetchData()
        }
        
     
        /*************
         * IMAGES
         *******************/
        func downloadImageGetFilepath(imageURL: String) async throws -> String{
            do{
                let filePath = try await imageModel.downloadImage(imageURL: imageURL)
                return filePath
            }catch{
                throw error
            }
        }
        func loadImageFromPath(_ path: String) -> UIImage? {
            let fileURL = getDocumentsDirectory().appendingPathComponent(path)
            return UIImage(contentsOfFile: fileURL.path)
        }
        
        func getDocumentsDirectory() -> URL {
            FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        }
        func loadImage(fromImageId imageId: String) -> UIImage? {
            let fileURL = getDocumentsDirectory().appendingPathComponent(imageId)
            return UIImage(contentsOfFile: fileURL.path)
        }
        enum CategoryError: Error {
            case missingTitle
            case titleTooLong
            var errorMessage: String {
                    switch self {
                    case .missingTitle:
                        return "Title is required."
                    case .titleTooLong:
                        return "Title length is max 35 characters."
                    }
                }
        }
        /*************
         * TODOS
         *******************/
        
        func fetchTodos(forCategoryId categoryId: String) -> [TodoTask] {
            return todos.filter { $0.category?.id == categoryId }
        }
        var prioTodos: [TodoTask] {
            todos.filter { $0.isPrio }
        }
        
        func addTodo(title: String, isDone: Bool, isPriority: Bool, date: Date?, category: Category2?){
            let resolvedCategory = category ?? Category2.defaultCategory
            
            let todo = TodoTask(title: title, isDone: isDone, isPrio: isPriority, date: date, category: resolvedCategory)
            modelContext.insert(todo)
            //fetchData()
            do {
                try modelContext.save()
                fetchData()
                updateFillLevel()
            } catch {
                print("Error saving todo: \(error)")
            }
        }
        func toggleIsDone(todoID: String) {
            if let index = todos.firstIndex(where: { $0.id == todoID }) {
                todos[index].isDone.toggle()
                fetchData()
                updateFillLevel()
            }
        }
        func deleteTodo(_ todoToDelete: TodoTask) {
            modelContext.delete(todoToDelete)
            
            do {
                try modelContext.save()
                
                fetchData()
                updateFillLevel()
            } catch {
                print("Error deleting todo and updating fill level: \(error)")
            }
        }
  
        func todosFiltered(forCategory category: Category2) -> [TodoTask] {
            todos.filter { $0.category?.id == category.id }
        }
        
        let dateFormatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateStyle = .short
            formatter.timeStyle = .none
            return formatter
        }()
        
        /*************
         * COFFECUP
         *******************/
        
        func coffeeImageName(for fillLevel: Int) -> String {
                "cup\(fillLevel)"
            }
        func fetchCurrentFillLevel() {
            let descriptor = FetchDescriptor<CoffeeCup>(predicate: nil)
            do {
                let coffeeCups = try modelContext.fetch(descriptor)
                if let coffeeCup = coffeeCups.first {
                    DispatchQueue.main.async {
                        self.fillLevel = coffeeCup.fillLevel
                    }
                }
            } catch {
                print("Error fetching current fill level: \(error)")
            }
        }
        func toggleIsDone(todo: TodoTask) {
            todo.isDone.toggle()
            do {
                try modelContext.save()
                updateFillLevel()
            } catch {
                print("Error toggling todo completion and updating fill level: \(error)")
            }
        }
        //Help from chat gpt :) 
        func updateFillLevel() {
            let descriptor = FetchDescriptor<CoffeeCup>(predicate: nil)
            do {
                let coffeeCups = try modelContext.fetch(descriptor)
                if let coffeeCup = coffeeCups.first {
                    let completedTodos = todos.filter { $0.isDone }.count
                    let totalTodos = todos.count
                    coffeeCup.fillLevel = totalTodos > 0 ? (completedTodos * totalHeights) / totalTodos : 0
                    
                    try modelContext.save()
                    DispatchQueue.main.async {
                        self.fillLevel = coffeeCup.fillLevel
                    }
                }
            } catch {
                print("Error updating fill level: \(error)")
            }
        }
    }
}

