//
//  ContentVViewModel.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-11.
//
/*
import Foundation
import SwiftUI
import SwiftData

extension ContentView{
    @Observable
    class ViewModel{
        var modelContext: ModelContext
        var categories = [Category2]()
        var todos = [TodoTask]()
        
        init(modelContext: ModelContext) {
            self.modelContext = modelContext
            fetchData()
        }
        
        func fetchData() {
            do {
                let descriptor = FetchDescriptor<TodoTask>(sortBy: [SortDescriptor(\.title)])
                todos = try modelContext.fetch(descriptor)
            } catch {
                print("Fetch failed")
            }
        }
    }
}
*/
