//
//  AppConfig.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-10.
//

import Foundation
import SwiftUI

//NOT IN USE IN THIS  COMMIT 
struct AppConfig{
    static let Group11AppSharedStorage: String = "group.jennysara"
    static let prioTodosKey: String = "prioTodosKey"
}
