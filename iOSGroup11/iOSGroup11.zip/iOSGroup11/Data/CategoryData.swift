//
//  CategoryData.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-04.
//

import Foundation
import SwiftData
import WidgetKit
@Model
final class Category2: Identifiable{
    @Attribute(.unique) let id = UUID().uuidString
    var title: String
    var imageId: String?
    var todos: [TodoTask] = []
    
    init(title: String, imageId: String?) {
        self.title = title
        self.imageId = imageId
       
    }
    
    
}
//https://chat.openai.com/share/7eb28419-bb9d-4bdf-94ba-a25f6c5f30f7

extension Category2 {
    static var defaultCategory: Category2 = {
        return Category2(title: "Default", imageId: nil)
    }()
   
        func addTodo(_ todo: TodoTask) {
            if todo.category !== self {
                todo.category?.removeTodo(todo)
            }
            todos.append(todo)
            todo.category = self
        }

        func removeTodo(_ todo: TodoTask) {
            guard let index = todos.firstIndex(where: { $0.id == todo.id }) else { return }
            todos.remove(at: index)
        }
    
}
