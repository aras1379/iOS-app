//
//  Extension.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-02-22.
//
/*
import Foundation
import SwiftUI
import SwiftData
//https://medium.com/mobile-app-development-publication/environment-keys-vs-environment-object-in-swiftui-e31385effb0d
private struct CategoriesViewModelKey: EnvironmentKey{
    static let defaultValue: CategoriesViewModel = CategoriesViewModel()
}

private struct TodoViewModelKey: EnvironmentKey{
    static let defaultValue: TodoViewModel = TodoViewModel()
}

extension EnvironmentValues{
    var categoriesViewModel: CategoriesViewModel{
        get{ self[CategoriesViewModelKey.self]}
        set{ self[CategoriesViewModelKey.self] = newValue}
    }
    var todosViewModel: TodoViewModel{
        get { self[TodoViewModelKey.self] }
        set{ self[TodoViewModelKey.self] = newValue}

    }
}

extension CategoriesViewModel {
    static var preview: CategoriesViewModel {
        let viewModel = CategoriesViewModel()
        // Add some sample categories
        viewModel.categories.append(contentsOf: [
          //  Category2(title: "Sample Category 1", imageId: "SampleImage1"),
           // Category2(title: "Sample Category 2", imageId: "SampleImage2")
        ])
        return viewModel
    }
}

extension CategoriesViewModel {
    static var preview2: CategoriesViewModel {
        let model = CategoriesViewModel()
       // model.categories.append(Category2(title: "Sample Category", imageId: nil))
        // Add more categories as needed
        return model
    }
}

private struct ModelContainerKey: EnvironmentKey {
    // Provide a default value or make it optional based on your needs
    static let defaultValue: ModelContainer? = nil
}

extension EnvironmentValues {
    var modelContainer: ModelContainer? {
        get { self[ModelContainerKey.self] }
        set { self[ModelContainerKey.self] = newValue }
    }
}
*/
