//
//  CoffeeCupViewModel.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-04.
//

import Foundation
import SwiftUI

@Observable
class CoffeeCupViewModel{
    
    var mockTodos = [TodoTask]()
    var fillLevel = 0
    let totalHeights = 14
    
  
    func updateFillLevel(){
        let markedDone = mockTodos.filter{$0.isDone}.count
        if markedDone == mockTodos.count {
            fillLevel = totalHeights
        } else {
            let fillIncrement = totalHeights / mockTodos.count
            fillLevel = (markedDone * fillIncrement)
            fillLevel = min(fillLevel, totalHeights)
        }
        
    }
}
