//
//  CategoriesViewModel.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-02-20.
//

import Foundation
import SwiftUI
import Observation
import SwiftData
import WidgetKit

@Observable
class CategoriesViewModel{
    
    var imageModel = ImageModel()
    var modelContext: ModelContext
    var images: [ImageData.ApiImage] = []
   
    var categories = [Category2]()
    var todos = [TodoTask]()
    var errorMessage: String?
   // var selectedImageURL: String?

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        fetchData()
    }
    func fetchData() {
        do {
            let descriptor = FetchDescriptor<Category2>(sortBy: [SortDescriptor(\.title)])
            categories = try modelContext.fetch(descriptor)
        } catch {
            print("Fetch failed")
        }
    }
    func addCategory(title: String, selectedImageURL: String?) async{
        guard let imageURL = selectedImageURL, !imageURL.isEmpty else { return }
        do {
            let backgroundImage = try await downloadImageGetFilepath(imageURL: imageURL)
            modelContext.insert(Category2(title: title, imageId: backgroundImage))
        }catch{
            print("\(error)")
        }
    }
    
    
    func updateCategory(catId: String, newTitle: String, newImageId: String?){
        if let index = categories.firstIndex(where: {$0.id == catId}){
            DispatchQueue.main.async{
                self.categories[index].title = newTitle
                self.categories[index].imageId = newImageId
            }
        }
    }
    

    
    func fetchTodos(forCategoryId categoryId: String) -> [TodoTask] {
        return todos.filter { $0.category?.id == categoryId }
       }
    
    func downloadImageGetFilepath(imageURL: String) async throws -> String{
        do{
            let filePath = try await imageModel.downloadImage(imageURL: imageURL)
            return filePath
        }catch{
            throw error
        }
    }
    

    
    
    //https://gist.github.com/perlguy99/5a0035bbd96529d3b5c20a9e0cd0bdfb
    // chatgpt : https://chat.openai.com/share/8ef79d9a-7986-45ee-aa74-ae332f3c6055
    func loadImageFromPath(_ path: String) -> UIImage? {
        let fileURL = getDocumentsDirectory().appendingPathComponent(path)
        return UIImage(contentsOfFile: fileURL.path)
    }
    
    func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }
    func loadImage(fromImageId imageId: String) -> UIImage? {
        let fileURL = getDocumentsDirectory().appendingPathComponent(imageId)
        return UIImage(contentsOfFile: fileURL.path)
    }
    
    func validateCategory(title: String) {
        do{
            guard !title.isEmpty else {
                throw CategoryError.missingTitle
            }
            guard title.count <= 35 else {
                throw CategoryError.titleTooLong
            }
            errorMessage = nil
        }catch{
            switch error{
            case CategoryError.missingTitle:
                errorMessage = "Title is required"
            case CategoryError.titleTooLong:
                errorMessage = "Title length is max 35 characters"
            default:
                errorMessage = "Unknown Error"
            }
        }
    }
   
}

enum CategoryError: Error {
    case missingTitle
    case titleTooLong
}

