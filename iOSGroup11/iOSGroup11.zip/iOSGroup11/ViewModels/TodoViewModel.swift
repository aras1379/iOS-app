//
//  TodoViewModel.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-02-14.
//

import Foundation
import SwiftUI
import Observation
import SwiftData
import Combine
import WidgetKit
@Observable
class TodoViewModel{
 //   var coffeeCupViewModel: CoffeeCupViewModel2?
    var modelContext: ModelContext
    
    var todos = [TodoTask]()
   
    var fillLevel = 0
    let totalHeights = 14

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        fetchData()
    }
    func fetchData() {
        do {
            let descriptor = FetchDescriptor<TodoTask>(sortBy: [SortDescriptor(\.title)])
            todos = try modelContext.fetch(descriptor)
        } catch {
            print("Fetch failed")
        }
    }
    var prioTodos: [TodoTask] {
           todos.filter { $0.isPrio }
       }
        
    func toggleIsDone(todoID: String) {
            if let index = todos.firstIndex(where: { $0.id == todoID }) {
                todos[index].isDone.toggle()
                updateFillLevelForPrioTodos()
            }
        }

        func updateFillLevelForPrioTodos() {
            let donePrioTodos = prioTodos.filter { $0.isDone }.count
            let totalPrioTodos = prioTodos.count
            fillLevel = totalPrioTodos > 0 ? (donePrioTodos * 14) / totalPrioTodos : 0
        }
        
    func updateFillLevel(){
        let markedDone = todos.filter{$0.isDone}.count
        if markedDone == todos.count {
            fillLevel = totalHeights
        } else {
            let fillIncrement = totalHeights / todos.count
            fillLevel = (markedDone * fillIncrement)
            fillLevel = min(fillLevel, totalHeights)
        }
        
    }
    
    func fillLevelTodos() -> Int {
        let completedTodos = todos.filter { $0.isDone && $0.isDone }.count
        let totalTodos = todos.filter{$0.isPrio}.count
        return totalTodos > 0 ? (completedTodos * 14) / totalTodos : 0
    }
    
  
//    var prioTodos: [TodoTask]{
  //      todos.filter{$0.isPrio}
   // }
    
  /*  func filteredTodos(for timeFrame: TimeFrame) -> [TodoTask] {
            todos.filter{$0.timeFrame == timeFrame}
        }
    */
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter
    }()
    
    func toggleIsDoneAndRecalculate(todoID: String) {
            if let index = todos.firstIndex(where: { $0.id == todoID }) {
                todos[index].isDone.toggle()
                updateFillLevel()
            }
        }
        
      /*  func updateFillLevel() {
            let markedDone = todos.filter { $0.isPrio && $0.isDone }.count
            let totalPrioTodos = todos.filter { $0.isPrio }.count
            fillLevel = totalPrioTodos > 0 ? (markedDone * totalHeights) / totalPrioTodos : 0
        }*/
   
    
    /*func updateFillLevel(){
        let markedDone = todos.filter{$0.isPrio && $0.isDone}.count
        let totalPrioTodos = todos.filter { $0.isPrio }.count
        fillLevel = totalPrioTodos > 0 ? (markedDone * totalHeights) / totalPrioTodos : 0
        
    }*/
    
    //https://chat.openai.com/share/cf72be15-e517-4992-90cb-5f3d66b9f1e3
  /*  static func sortUpcomingTodos(_ todos: [TodoTask]) -> [TodoTask] {
        var upcomingTodos = todos.filter { $0.timeFrame == .Upcoming }
        
        upcomingTodos.sort { (firstTodo, secondTodo) -> Bool in
            if let firstDate = firstTodo.date, let secondDate = secondTodo.date {
                return firstDate < secondDate
            }
            return false
        }
        return upcomingTodos
    }
   */
}

