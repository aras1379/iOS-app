//
//  AppManager.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-02-22.
//

import Foundation
import SwiftUI
import WidgetKit
/*
@Observable
class AppManager{
    static let shared = AppManager()
    let todoViewModel: TodoViewModel
    let categoriesViewModel: CategoriesViewModel

    init() {
        todoViewModel = TodoViewModel()
        categoriesViewModel = CategoriesViewModel()
    }
}
*/
