//
//  CoffeeCupViewModel.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-04.
//

import Foundation
import SwiftUI

@Observable
class CoffeeCupViewModel2: Identifiable {
    

    
    var todos = [TodoTask]()
    var fillLevel = 0
    let totalHeights = 14

    func updateFillLevel(){
        let markedDone = todos.filter{$0.isPrio && $0.isDone}.count
        if markedDone == todos.count {
            fillLevel = totalHeights
        } else {
            let fillIncrement = totalHeights / todos.count
            fillLevel = (markedDone * fillIncrement)
            fillLevel = min(fillLevel, totalHeights)
        }
        
    }
}

