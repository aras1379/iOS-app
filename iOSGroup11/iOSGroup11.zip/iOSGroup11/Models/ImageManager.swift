//
//  PatternModel.swift
//  iOSGroup11
//
//  Created by Jenny Gran on 2024-02-14.
//

import Foundation
import Observation
/*
@Observable
class ImageModel: Identifiable {
    let id: String
    
    init(image: ImageData, baseUrl: String, feedUrl: String) {
        id = image.images.id
    }
}
*/
