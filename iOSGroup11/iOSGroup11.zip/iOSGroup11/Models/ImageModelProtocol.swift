//
//  ImageModelProtocol.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-03-11.
//
/*
import Foundation
public protocol ImageModelProtocol {
    func downloadImage(imageURL: String) async throws -> String
}
*/
