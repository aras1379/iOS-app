//
//  TodoModel.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-02-14.
//
/*
import Foundation
import SwiftUI
import Observation

struct Todo: Identifiable{
    var id = UUID()
    var title: String
    var isDone = false
    var isPrio: Bool
    var date: Date?
    var category: String
    */
    //https://chat.openai.com/share/314853e7-e5b1-4eb7-92f1-841e103f50b8
    /*  var timeFrame: TimeFrame {
     if let date = date {
     let now = Date()
     let calendar = Calendar.current
     let startOfDay = calendar.startOfDay(for: now) //midnight current day
     let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)! // midnight upcoming day
     
     if date > endOfDay {
     return .Upcoming
     //https://developer.apple.com/documentation/foundation/calendar/2293243-isdateintoday
     } else if calendar.isDateInToday(date) {
     return .Today
     } else {
     return .Whenever
     }
     } else {
     return .Whenever
     }
     }
     
     //https://chat.openai.com/share/cf72be15-e517-4992-90cb-5f3d66b9f1e3
     static func sortUpcomingTodos(_ todos: [Todo]) -> [Todo] {
     var upcomingTodos = todos.filter { $0.timeFrame == .Upcoming }
     
     upcomingTodos.sort { (firstTodo, secondTodo) -> Bool in
     if let firstDate = firstTodo.date, let secondDate = secondTodo.date {
     return firstDate < secondDate
     }
     return false
     }
     return upcomingTodos
     }
     }
     
     enum TimeFrame: String, CaseIterable, Identifiable {
     case Today, Upcoming, Whenever
     var id: Self { self }
     }
     
     */
