//
//  PreviewSampleData.swift
//  iOSGroup11
//
//  Created by Jenny Gran on 2024-03-06.
//

import SwiftUI
import SwiftData
/*
//https://developer.apple.com/videos/play/wwdc2023/10154/
@MainActor
let previewContainer: ModelContainer = {
    do {
        let container = try ModelContainer(
            for: TodoTask.self, ModelConfiguration(inMemory: true)
        )
        container.mainContext.insert(todo: todo)
    return container
    } catch {
        fatalError("Failed to create container")
    }
}()
*/
