//
//  AddTodosView.swift
//  iOSGroup11
//
//  Created by Jenny Gran on 2024-02-23.
//

import SwiftUI
import SwiftData

struct AddTodosView: View {
    let viewModel: StartPageView.ViewModel
    @State var modelContext: ModelContext
    
    @Environment(\.dismiss) private var dismiss
    
    //@Query private var categories: [Category2]
    //@Query private var todos: [TodoTask]
        
    @State private var titleInput = ""
    @State private var isPriority = false
    @State var selectedCategory: Category2 = Category2.defaultCategory
    @State private var currentDate = Date()
    @State private var selectedDate: Date?
    @State private var isDone = false
    @State private var showingDatePicker = false
    @State private var savedTodo = false
    @State private var showError = false
    let errorMessage: String = "Title can not be empty"
    
    var body: some View {
        VStack {
            TextField("Title", text: $titleInput)
                .padding()
                .textFieldStyle(.roundedBorder)
            
            HStack {
                Text("Category:")
                Picker(selection: $selectedCategory, label: Text("Category")) {
                    ForEach(viewModel.categories, id: \.self) { category in
                        //https://chat.openai.com/share/49f22bc1-389c-4c8d-a6a7-a354c69d47eb
                        Text(category.title).tag(category as Category2)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()    
            }
            
            Toggle("Priority", isOn: $isPriority)
                .padding()
            
            if showingDatePicker {
                DatePicker("Date", selection: $currentDate,
                           in: Date()...,
                           displayedComponents: .date)
                .datePickerStyle(GraphicalDatePickerStyle())
                .padding()
            }
            
            Button(action: {
                self.showingDatePicker.toggle()
            }) {
                Text(showingDatePicker ? "Hide Date" : "Select Date")
            }
            
            Spacer()
            
            Button(action: {
                savedTodo = true
                
                if titleInput.isEmpty {
                    showError = true
                    return
                }
                viewModel.addTodo(title: titleInput, isDone: isDone, isPriority: isPriority, date: showingDatePicker ? currentDate : selectedDate, category: selectedCategory)
                
                
                dismiss()
            }) {
                Text("Save")
                    .foregroundColor(.black)
            }
            .buttonStyle(.bordered)
            .padding()
        }
        .navigationTitle("Add Todo")
        .alert(errorMessage,
               isPresented: $showError) {
            Button("OK", role: .cancel) {}
        }
    }

}

/*
#Preview{
    AddTodosView()
        .modelContainer(for: TodoTask.self, inMemory: true)
}
*/
