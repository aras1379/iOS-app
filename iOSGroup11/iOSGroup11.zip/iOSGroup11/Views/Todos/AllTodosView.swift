//
//  TodosAllView.swift
//  iOSGroup11
//
//  Created by Sara Ljung on 2024-02-22.
//

import SwiftUI
import SwiftData
import WidgetKit

struct AllTodosView: View {
    let viewModel: StartPageView.ViewModel
    @State var modelContext: ModelContext
    
  //  @Query private var todos: [TodoTask]
    @State private var isAddingTodo = false
    @State private var isEditTodo = false
    
  /*  var sortedUpcomingTodos: [TodoTask] {
        TodoViewModel.sortUpcomingTodos(todoViewModel.filteredTodos(for: .Upcoming))
    } */
    
    var body: some View {
        VStack {
            NavigationStack {
                TodoFilteredView(viewModel: viewModel, modelContext: modelContext, todos: viewModel.todos)
            }
            .frame(maxHeight: .infinity)
            .listStyle(PlainListStyle())
            
            Spacer()
            //https://developer.apple.com/documentation/familycontrols/familyactivityiconview/navigationdestination(ispresented:destination:)?changes=latest_minor
                .navigationDestination(isPresented: $isAddingTodo) {
                    AddTodosView(viewModel: viewModel, modelContext: modelContext)
                }
            
            Button(action: {
                isAddingTodo = true
            }) {
                Text("New todo")
                    .foregroundColor(.black)
            }
            .buttonStyle(.bordered)
            .padding()
            .onTapGesture {
                isAddingTodo = true
            }
        }
        .navigationTitle(isAddingTodo ? "Add todo" : "All Todos")
    }
}


/*
#Preview {
    AllTodosView()
        .modelContainer(for: Category2.self, inMemory: true)
        .modelContainer(for: TodoTask.self, inMemory: true)
}
*/
