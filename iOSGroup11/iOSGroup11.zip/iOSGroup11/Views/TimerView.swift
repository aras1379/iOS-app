//
//  TimerScreen.swift
//  iOSGroup11
//
//  Created by Jenny Gran on 2024-02-20.
//

import SwiftUI

struct TimerView: View {
    @State private var timerViewModel = TimerViewModel()
    
    var body: some View {
        VStack {
            Text("Timer")
                .font(.largeTitle)
                .fontWeight(.medium)
                .padding(3.0)
            NavigationStack {
                VStack(spacing: 40) {
                    ZStack {
                        Circle()
                            .frame(width: 500, height: 250)
                            .foregroundColor(.white)
                        //https://chat.openai.com/share/de112f08-04f6-4ac2-997b-2f58f76fda1d
                        Circle()
                            .trim(from: 0.0, to: CGFloat(timerViewModel.progress))
                            .stroke(style: StrokeStyle(lineWidth: 20, lineCap: .round, lineJoin: .round))
                            .foregroundColor(.green)
                            .rotationEffect(.degrees(-90))
                            .frame(width: 250, height: 250)
                            .animation(.easeInOut, value: timerViewModel.progress)
                        Text("\(timerViewModel.timerValue)")
                            .font(.title)
                    }
                    .padding()
                    HStack {
                      Picker(selection: $timerViewModel.hours, label: Text("Hours")) {
                            ForEach(0..<24) { hour in
                                Text(timerViewModel.isTimerStarted ? "0" : "\(hour)")
                            }
                        }
                        .pickerStyle(WheelPickerStyle())
                        .frame(width: 100)
                        Text(":")
                       Picker(selection: $timerViewModel.minutes, label: Text("Minutes")) {
                            ForEach(0..<60) { minute in
                                Text(timerViewModel.isTimerStarted ? "0" : "\(minute)")
                            }
                        }
                        .pickerStyle(WheelPickerStyle())
                        .frame(width: 100)
                        Text(":")
                       Picker(selection: $timerViewModel.seconds, label: Text("Seconds")) {
                            ForEach(0..<60) { second in
                                Text(timerViewModel.isTimerStarted ? "0" : "\(second)")
                            }
                        }
                        .pickerStyle(WheelPickerStyle())
                        .frame(width: 100)
                        .disabled(timerViewModel.isTimerStarted)
                    }
                    
                    HStack(spacing: 35) {
                        Button(action: { if timerViewModel.isTimerStarted { timerViewModel.stopTimer() } else {
                            timerViewModel.startTimer()
                        }
                        }, label: {
                            Text(timerViewModel.isTimerStarted ? "Stop" : "Start")
                                .foregroundColor(.black)
                        })
                        .buttonStyle(.bordered)
                        Button(action: { timerViewModel.clearTimer() },
                               label: { Text("Clear")
                                .foregroundColor(.black)
                        })
                        .buttonStyle(.bordered)
                    }
                }
                .padding(.bottom, 250)
            }
        }
    }
}

#Preview {
    TimerView()
}
